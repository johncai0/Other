#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <curl/curl.h>
#include <time.h>
#include <openssl/md5.h>
#include <ctype.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <errno.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>

#define NON_NUM '0'
#define MAX_BUF	8192
#define USER_AGENT	"Accept: Rkylin-monitor V1.0"
#define TMP_FILE	"/tmp/a.html"
#define LOG_FILE	"./my.log"

char Char2Num(char ch){ 
	if(ch>='0' && ch<='9')return (char)(ch-'0'); 
	if(ch>='a' && ch<='f')return (char)(ch-'a'+10); 
	if(ch>='A' && ch<='F')return (char)(ch-'A'+10); 
	return NON_NUM; 
} 


int URLEncode(const char* str, const int strSize, char* result, const int resultSize) { 
	int i; 
	int j = 0; /* for result index */ 
	char ch; 

	if ((str == NULL) || (result == NULL) || (strSize <= 0) || (resultSize <= 0)) { 
		return 0; 
	} 

	for (i=0; (i<strSize) && (j<resultSize); i++) { 
		ch = str[i]; 
		if ((ch >= 'A') && (ch <= 'Z')) { 
			result[j++] = ch; 
		} else if ((ch >= 'a') && (ch <= 'z')) { 
			result[j++] = ch; 
		} else if ((ch >= '0') && (ch <= '9')) { 
			result[j++] = ch; 
		} else if(ch == ' '){ 
			result[j++] = '%'; 
			result[j++] = '2'; 
			result[j++] = '0'; 
		} else if (ch == '-') {
			result[j++] = '-';
		} else { 
			if (j + 3 < resultSize) { 
				sprintf(result+j, "%%%02X", (unsigned char)ch); 
				j += 3; 
			} else { 
				return 0; 
			} 
		} 
	} 

	result[j] = '\0'; 
	return j; 
}
void getlocaltime(char *dest)
{
	time_t timenu;
	time(&timenu);
	struct tm *tminfo;
	tminfo = localtime(&timenu);
	char buf[20];
	sprintf(buf,"%d-%02d-%02d %02d:%02d:%02d\0",
			tminfo->tm_year+1900,tminfo->tm_mon+1,
			tminfo->tm_mday,tminfo->tm_hour,tminfo->tm_min,tminfo->tm_sec);
	strcpy(dest,buf);
}

void getMD5(char *method,char *app_key,char *format,char *time,char *session,unsigned char *md5_str)
{

	int i;
	unsigned char md5_value[16];
	char buf[8192];
	char *secret = "3A967ECF-4FF7-445F-980E-7725D9CC2305";
	MD5_CTX md5;
	MD5_Init(&md5);
	sprintf(buf,"%sapp_key%sformat%smethod%ssession%stimestamp%s%s",secret,app_key,format,method,session,time,secret);
	//printf("ZHUANHUAN STR ==> %s\n",buf);
	MD5_Update(&md5, buf, strlen(buf));
	MD5_Final(md5_value, &md5);
	for(i = 0; i < 16; i++)
	{
		snprintf(md5_str + i*2, 2+1, "%02x", md5_value[i]);
	}
	md5_str[32] = '\0'; // add end
	for (i = 0; i < 33; i++) {
		md5_str[i] = toupper(md5_str[i]);
	}
}

void get_url(char *req_url)
{
	char time[20];
	char timecode[1024],url[256];
	unsigned char md5[33];
	memset(&md5,'\0',34);
	getlocaltime(time);
	char *method = "ruixue.wheatfield.bank.query";
	char *app_key = "EE3DEB16-CAD3-40D1-8A9A-C9C29034EBD4";
	char *format = "xml";
	char *session = "c04270b9-ea02-4409-ae64-3f8c0c6b6e22";
	char *host = "https://api.open.ruixuesoft.com:30005/ropapi?";
	getMD5(method,app_key,format,time,session,md5);
	URLEncode(time,strlen(time),timecode,1024);
	sprintf(url,"%smethod=%s&app_key=%s&format=%s&timestamp=%s&session=%s&sign=%s",host,method,app_key,format,timecode,session,md5);
	strcpy(req_url,url);
}

void get_request(char *cont)
{
	CURL *curl;
	CURLcode res;
	//char *url = "https://api.open.ruixuesoft.com:30005/ropapi";
	char url[256];
	get_url(url);
	//printf("%d == %s\n",strlen(url),url);
	struct curl_slist *headers = NULL;
	char buf[MAX_BUF];
	memset(&buf,'\0',MAX_BUF);
	headers = curl_slist_append(headers, USER_AGENT);
	curl = curl_easy_init();
	FILE *fp = NULL;
	if ((fp = fopen(TMP_FILE,"w+r")) == NULL) {
		fprintf(stdout,"open Tmp file Error!\n");
		exit(-1);
	}
	if (curl)
	{
		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
		curl_easy_setopt(curl, CURLOPT_URL, url);
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0);
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);
		//curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);//调试信息打开

		res = curl_easy_perform(curl);
		curl_slist_free_all(headers);
		curl_easy_cleanup(curl);
	}
	rewind(fp);
	fread(buf,1,MAX_BUF,fp);
	fclose(fp);
	//fprintf(stdout,"getNR: \n\r\n%s",buf);
	strcpy(cont,buf);
}

char *htmlerr() {
	return "HTTP/1.1 404 Not Found\r\nServer: MyServer/1.3\r\nContent-Type: text/xml; charset=UTF-8\r\n\r\n"
		"<html><title>ERROR</title><body><h3>Requst Error In Server!!!<h3></body></html>";
}
void gethtml(char *send)
{
	char xml[MAX_BUF];
	memset(&xml,'\0',MAX_BUF);
	get_request(xml);
	char buffer[strlen(xml)+90];
	sprintf(buffer,"HTTP/1.1 200 OK\r\nServer: MyServer/1.3\r\nContent-Type: text/xml; charset=UTF-8\r\n\r\n%s",xml);
	//printf("%s\n",buffer);
	strcpy(send,buffer);
}
void writelog(char *logstr)
{
	FILE *fp = NULL;
	if ((fp = fopen(LOG_FILE,"a+")) == NULL) {
		fprintf(stderr,"open and create log :: error:: %s\n",strerror(errno));
	}
	if (fwrite(logstr, strlen(logstr), 1,fp) != 1) {
		fprintf(stderr,"write log :: error:: %s\n",strerror(errno));
	}
	fclose(fp);

}
int main(int argc, char **argv) {

	char *ip = "127.0.0.1";
	char lotm[20],log[512];
	int port = 8888;
	int server_sock, client_sock;
	struct sockaddr_in my_addr;
	struct sockaddr_in remote_addr;
	int sin_size, yes = 1;
	char buf[MAX_BUF];
	memset(&my_addr,0,sizeof(my_addr));
	ssize_t sz = 0;

	if (fork() != 0) {
		exit(0);
	}

	if ((server_sock = socket(AF_INET,SOCK_STREAM,0)) == -1) {
		fprintf(stderr,"socket:: error:: %s\n",strerror(errno));
		return -1;
	}
	if (setsockopt(server_sock, SOL_SOCKET,SO_REUSEADDR, &yes, sizeof(int)) < 0) {
		fprintf(stderr,"setsockopt:: error:: %s\n",strerror(errno));
		return -8;
	}

	my_addr.sin_family=AF_INET;
	my_addr.sin_addr.s_addr=INADDR_ANY;
	my_addr.sin_port=htons(port);

	if (bind(server_sock,(struct sockaddr *)&my_addr,sizeof(my_addr)) < 0) {
		fprintf(stderr,"bind:: error:: %s\n",strerror(errno));
		return -2;
	}

	if (listen(server_sock,100) < 0) {
		fprintf(stderr,"listen:: error:: %s\n",strerror(errno));
		return -3;
	}

	while (1) {
		memset(&remote_addr,0,sizeof(remote_addr));
		sin_size = sizeof(remote_addr);
		if ((client_sock = accept(server_sock,(struct sockaddr *)&remote_addr,&sin_size)) < 0) {
			memset(&lotm,'\0',20);
			memset(&log,'\0',512);
			getlocaltime(lotm);
			sprintf(log,"[%s] ERROR :: accept:: %s\r\n", lotm, strerror(errno));
			writelog(log);
		}
		memset(&lotm,'\0',20);
		memset(&log,'\0',512);
		getlocaltime(lotm);
		sprintf(log,"[%s] ^-^ :: A new connect from %s:%d \r\n", lotm, inet_ntoa(remote_addr.sin_addr),htons(remote_addr.sin_port));
		writelog(log);
		memset(&buf,0,MAX_BUF);
		if ((sz = read(client_sock,buf,MAX_BUF)) == -1) {
			memset(&lotm,'\0',20);
			memset(&log,'\0',512);
			getlocaltime(lotm);
			sprintf(log,"[%s] ERROR :: read :: %s\r\n", lotm, strerror(errno));
			writelog(log);
		}
		//fprintf(stdout,"%s\n",buf);
		memset(&buf,0,MAX_BUF);
		gethtml(buf);
		if ((sz = write(client_sock,buf,strlen(buf))) == -1) {
			memset(&lotm,'\0',20);
			memset(&log,'\0',512);
			getlocaltime(lotm);
			sprintf(log,"[%s] ERROR :: wirte :: %s\r\n", lotm, strerror(errno));
			writelog(log);
		}
		memset(&lotm,'\0',20);
		memset(&log,'\0',512);
		getlocaltime(lotm);
		sprintf(log,"[%s] v-v :: connect closed %s:%d \r\n", lotm, inet_ntoa(remote_addr.sin_addr),htons(remote_addr.sin_port));
		writelog(log);
		shutdown(client_sock, SHUT_RDWR);
		close(client_sock);
	}
	return 0;
}
