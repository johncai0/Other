#include <stdio.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#define MAX_BUF	1024
int sock_fd;

char *html() {
	return "HTTP/1.1 200 OK\r\nServer: MyServer/1.3\r\nContent-Type: text/html\r\n\r\n"
		"<html><title>Test</title><body><h3>John's Test Pages!!!<h3></body></html>";
}

//void loop(int *clientsock)
void loop(void)
{
	int client_sock = sock_fd;
	char buf[MAX_BUF];
	//fprintf(stdout,"clientsock p == %p d == %d\nclient_SOCK p == %p d== %d\n",clientsock,*clientsock, &client_sock,client_sock);
	fprintf(stdout,"clientsock p == %p d == %d\nclient_SOCK p == %p d== %d\n", sock_fd, &sock_fd, &client_sock,client_sock);
	ssize_t sz = 0;
	memset(&buf,0,sizeof(buf));
	if ((sz = read(client_sock,buf,MAX_BUF)) == -1) {
		fprintf(stderr,"socket read:: error:: %s\n",strerror(errno));
	}
	//fprintf(stdout,"%s\n",buf);
	if ((sz = write(client_sock,html(),strlen(html()))) == -1) {
		fprintf(stderr,"socket write:: error:: %s\n",strerror(errno));
	}
	close(client_sock);
}

int main(int argc, char **argv) {

	char *ip = "127.0.0.1";
	int port = 8888;
	int server_sock, client_sock;
	struct sockaddr_in my_addr;
	struct sockaddr_in remote_addr;
	int sin_size,yes = 1;
	memset(&my_addr,0,sizeof(my_addr));

	//if (fork() != 0) {
	//	exit(0);
	//}

	if ((server_sock = socket(AF_INET,SOCK_STREAM,0)) == -1) {
		fprintf(stderr,"socket:: error:: %s\n",strerror(errno));
		return -1;
	}
	if (setsockopt(server_sock, SOL_SOCKET,SO_REUSEADDR, &yes, sizeof(int)) < 0) {
		fprintf(stderr,"setsockopt:: error:: %s\n",strerror(errno));
		return -8;
	}

	my_addr.sin_family=AF_INET;
	my_addr.sin_addr.s_addr=INADDR_ANY;
	my_addr.sin_port=htons(port);

	if (bind(server_sock,(struct sockaddr *)&my_addr,sizeof(my_addr)) < 0) {
		fprintf(stderr,"bind:: error:: %s\n",strerror(errno));
		return -2;
	}

	if (listen(server_sock,100) < 0) {
		fprintf(stderr,"listen:: error:: %s\n",strerror(errno));
		return -3;
	}

	while (1) {
		memset(&remote_addr,0,sizeof(remote_addr));
		sin_size = sizeof(remote_addr);
		if ((client_sock = accept(server_sock,(struct sockaddr *)&remote_addr,&sin_size)) < 0) {
			fprintf(stderr,"accept:: error:: %s\n",strerror(errno));
			return -4;
		}
		sock_fd = client_sock;
		printf("YY:: A new connect from %s:%d \r\n", inet_ntoa(remote_addr.sin_addr),htons(remote_addr.sin_port));
		pthread_t id;
		//if (pthread_create(&id,NULL,(void *)loop, &client_sock) != 0)
		if (pthread_create(&id,NULL,(void *)loop, (void *)NULL) != 0)
			fprintf(stderr,"pthread_create :: error :: create thread ERROR");
		//usleep(100);
	}	

}
