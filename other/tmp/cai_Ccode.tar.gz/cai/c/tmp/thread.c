#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

void thread(int *a)
{
	printf("number = %d\n", a);
	sleep(10000);
}

int main(void)
{
	pthread_t id;
	int i,ret;
	for (i = 1; i < 10; i++) {
		ret=pthread_create(&id,NULL,(void *) thread,&i); // 成功返回0，错误返回错误编号
		if(ret!=0) {
			printf ("Create pthread error!\n");
			exit (1);
		}
		if (i%2000 == 0)
			fprintf(stdout,"create %d threads!\n",i);
		usleep(200);
	}
	printf("This is the main process.\n");
	//pthread_join(id,NULL);
	sleep(10000);
	return (0);
}
